#!/usr/bin/env python3
"""
refresh_holo_data.py — feeds the low-pop holo dashboard.

Reads PriceCharting set pages for PSA 9 / PSA 10 values, and optionally card
pages for PSA population counts, then writes holo-data.js next to the
dashboard. The dashboard loads that file with a <script> tag, so no local web
server is needed: run this, reload the page.

Python 3.8+, standard library only.

  # everything (slow: 59 sets, one request each, 2s apart)
  python3 refresh_holo_data.py --all

  # a few sets
  python3 refresh_holo_data.py --sets "Neo Genesis,Fossil,Mysterious Treasures"

  # also walk each card's page for PSA 9/10 population (many more requests)
  python3 refresh_holo_data.py --sets "Neo Genesis" --pop

  # parse a page you saved from your browser instead of fetching it
  python3 refresh_holo_data.py --file ~/Downloads/neo.html --set "Neo Genesis"

  # show what the parser sees, for when a page changes shape
  python3 refresh_holo_data.py --sets "Fossil" --inspect

Notes
  - Responses are cached under .holo-cache/ so re-runs are cheap. --fresh skips it.
  - Requests are spaced out and identify themselves. Keep --delay polite.
  - PriceCharting's terms steer automated access towards their paid API. This
    script reads the same pages a browser does, at a slow pace, for personal use.
  - Population on PriceCharting is a mirror of PSA's report, not PSA itself.
"""

import argparse
import gzip
import io
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from html.parser import HTMLParser

BASE = "https://www.pricecharting.com"
CACHE = ".holo-cache"
UA = "holo-desk-refresher/1.0 (personal dashboard; contact: local user)"

# set name -> PriceCharting console slug, matching the dashboard
SETS = [
    ("Base Set", "pokemon-base-set"),
    ("Jungle", "pokemon-jungle"),
    ("Fossil", "pokemon-fossil"),
    ("Base Set 2", "pokemon-base-set-2"),
    ("Team Rocket", "pokemon-team-rocket"),
    ("Gym Heroes", "pokemon-gym-heroes"),
    ("Gym Challenge", "pokemon-gym-challenge"),
    ("Neo Genesis", "pokemon-neo-genesis"),
    ("Neo Discovery", "pokemon-neo-discovery"),
    ("Neo Revelation", "pokemon-neo-revelation"),
    ("Legendary Collection", "pokemon-legendary-collection"),
    ("Neo Destiny", "pokemon-neo-destiny"),
    ("Expedition", "pokemon-expedition"),
    ("Aquapolis", "pokemon-aquapolis"),
    ("Skyridge", "pokemon-skyridge"),
    ("EX Ruby & Sapphire", "pokemon-ruby-&-sapphire"),
    ("EX Sandstorm", "pokemon-sandstorm"),
    ("EX Dragon", "pokemon-dragon"),
    ("EX Team Magma vs Team Aqua", "pokemon-team-magma-vs-team-aqua"),
    ("EX Hidden Legends", "pokemon-hidden-legends"),
    ("EX FireRed & LeafGreen", "pokemon-firered-&-leafgreen"),
    ("EX Team Rocket Returns", "pokemon-team-rocket-returns"),
    ("EX Deoxys", "pokemon-deoxys"),
    ("EX Emerald", "pokemon-emerald"),
    ("EX Unseen Forces", "pokemon-unseen-forces"),
    ("EX Delta Species", "pokemon-delta-species"),
    ("EX Legend Maker", "pokemon-legend-maker"),
    ("EX Holon Phantoms", "pokemon-holon-phantoms"),
    ("EX Crystal Guardians", "pokemon-crystal-guardians"),
    ("EX Dragon Frontiers", "pokemon-dragon-frontiers"),
    ("EX Power Keepers", "pokemon-power-keepers"),
    ("Diamond & Pearl", "pokemon-diamond-&-pearl"),
    ("Mysterious Treasures", "pokemon-mysterious-treasures"),
    ("Secret Wonders", "pokemon-secret-wonders"),
    ("Great Encounters", "pokemon-great-encounters"),
    ("Majestic Dawn", "pokemon-majestic-dawn"),
    ("Legends Awakened", "pokemon-legends-awakened"),
    ("Stormfront", "pokemon-stormfront"),
    ("Platinum", "pokemon-platinum"),
    ("Rising Rivals", "pokemon-rising-rivals"),
    ("Supreme Victors", "pokemon-supreme-victors"),
    ("Arceus", "pokemon-arceus"),
    ("HeartGold & SoulSilver", "pokemon-heartgold-&-soulsilver"),
    ("HS Unleashed", "pokemon-unleashed"),
    ("HS Undaunted", "pokemon-undaunted"),
    ("HS Triumphant", "pokemon-triumphant"),
    ("Call of Legends", "pokemon-call-of-legends"),
    ("Black & White", "pokemon-black-&-white"),
    ("Emerging Powers", "pokemon-emerging-powers"),
    ("Noble Victories", "pokemon-noble-victories"),
    ("Next Destinies", "pokemon-next-destinies"),
    ("Dark Explorers", "pokemon-dark-explorers"),
    ("Dragons Exalted", "pokemon-dragons-exalted"),
    ("Dragon Vault", "pokemon-dragon-vault"),
    ("Boundaries Crossed", "pokemon-boundaries-crossed"),
    ("Plasma Storm", "pokemon-plasma-storm"),
    ("Plasma Freeze", "pokemon-plasma-freeze"),
    ("Plasma Blast", "pokemon-plasma-blast"),
    ("Legendary Treasures", "pokemon-legendary-treasures"),
]
SLUG = dict(SETS)


# ---------------------------------------------------------------- fetching

def fetch(url, delay=2.0, use_cache=True, tries=3):
    """GET a page, cached on disk. Returns text or None."""
    os.makedirs(CACHE, exist_ok=True)
    key = re.sub(r"[^A-Za-z0-9._-]", "_", url)[-150:]
    path = os.path.join(CACHE, key + ".html")
    if use_cache and os.path.exists(path):
        with open(path, encoding="utf-8", errors="replace") as fh:
            return fh.read()

    req = urllib.request.Request(url, headers={
        "User-Agent": UA,
        "Accept": "text/html,application/xhtml+xml",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip",
    })
    last = None
    for attempt in range(tries):
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                raw = resp.read()
                if resp.headers.get("Content-Encoding") == "gzip":
                    raw = gzip.GzipFile(fileobj=io.BytesIO(raw)).read()
                text = raw.decode("utf-8", errors="replace")
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(text)
            time.sleep(delay)
            return text
        except urllib.error.HTTPError as err:
            last = "HTTP %s" % err.code
            if err.code in (403, 404, 410):
                break
            time.sleep(delay * (attempt + 2))
        except Exception as err:                      # noqa: BLE001
            last = str(err)
            time.sleep(delay * (attempt + 2))
    print("    could not fetch (%s): %s" % (last, url), file=sys.stderr)
    return None


# ---------------------------------------------------------------- parsing

class Tables(HTMLParser):
    """Collect every table as rows of (cell text, first href in cell)."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tables = []
        self._tbl = None
        self._row = None
        self._cell = None
        self._href = None
        self._depth = 0

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "table":
            self._depth += 1
            if self._depth == 1:
                self._tbl = []
        elif tag == "tr" and self._tbl is not None:
            self._row = []
        elif tag in ("td", "th") and self._row is not None:
            self._cell, self._href = [], None
        elif tag == "a" and self._cell is not None and self._href is None:
            self._href = a.get("href")

    def handle_endtag(self, tag):
        if tag in ("td", "th") and self._cell is not None:
            txt = re.sub(r"\s+", " ", "".join(self._cell)).strip()
            self._row.append((txt, self._href))
            self._cell, self._href = None, None
        elif tag == "tr" and self._row is not None:
            if self._row:
                self._tbl.append(self._row)
            self._row = None
        elif tag == "table":
            if self._depth == 1 and self._tbl:
                self.tables.append(self._tbl)
                self._tbl = None
            self._depth = max(0, self._depth - 1)

    def handle_data(self, data):
        if self._cell is not None:
            self._cell.append(data)


def tables_of(html):
    p = Tables()
    p.feed(html)
    return p.tables


MONEY = re.compile(r"\$\s*([\d,]+(?:\.\d+)?)")
COUNT = re.compile(r"^\s*([\d,]+)\s*$")


def money(text):
    m = MONEY.search(text or "")
    if not m:
        return None
    try:
        return round(float(m.group(1).replace(",", "")), 2)
    except ValueError:
        return None


def count(text):
    m = COUNT.match(text or "")
    if not m:
        return None
    try:
        return int(m.group(1).replace(",", ""))
    except ValueError:
        return None


def header_map(header):
    """Map column index -> role, using the header text rather than css classes."""
    roles = {}
    for i, (txt, _) in enumerate(header):
        t = txt.lower()
        if not t:
            continue
        if re.search(r"\b(card|title|name|product)\b", t) and "number" not in t:
            roles.setdefault("name", i)
        elif re.search(r"(number|^#$|\bno\.?\b)", t):
            roles.setdefault("num", i)
        elif re.search(r"(psa\s*10|gem[\s-]*mint|grade\s*10|\b10\b)", t) and "9" not in t:
            roles["pop10" if "pop" in t else "v10"] = i
        elif re.search(r"(grade\s*9(?!\.5|\.0?5)|psa\s*9|\b9\b)", t) and "9.5" not in t:
            roles["pop9" if "pop" in t else "v9"] = i
        elif re.search(r"ungraded|loose|raw", t):
            roles.setdefault("raw", i)
    return roles


def pick_table(tables, want=("v9", "v10")):
    """Best table: has a usable header and the most data rows."""
    best, best_rows, best_roles = None, 0, None
    for tbl in tables:
        if len(tbl) < 2:
            continue
        for head_i in (0, 1):
            if head_i >= len(tbl):
                continue
            roles = header_map(tbl[head_i])
            if not any(k in roles for k in want):
                continue
            rows = tbl[head_i + 1:]
            if len(rows) > best_rows:
                best, best_rows, best_roles = rows, len(rows), roles
        # tables whose header is not in a th row still land here via head_i=0
    return best, best_roles


def clean_name(raw):
    """'Charizard #4 [1st Edition]' -> ('Charizard', '4', '1st Edition')"""
    name = re.sub(r"\s+", " ", raw or "").strip()
    variant = ""
    vm = re.search(r"[\[(]([^\])]+)[\])]\s*$", name)
    if vm:
        variant = vm.group(1).strip()
        name = name[:vm.start()].strip()
    num = ""
    nm = re.search(r"#\s*([A-Za-z]{0,3}\d+[a-z]?)\s*$", name)
    if nm:
        num = nm.group(1)
        name = name[:nm.start()].strip()
    name = name.strip(" -–·,")
    return name, num, variant


def parse_set_page(html):
    """-> list of dicts with name, num, variant, v9, v10, href"""
    rows, roles = pick_table(tables_of(html))
    out = []
    if not rows or not roles:
        return out, roles
    for row in rows:
        def cell(role):
            i = roles.get(role)
            return row[i][0] if (i is not None and i < len(row)) else ""

        i_name = roles.get("name", 0)
        raw_name = row[i_name][0] if i_name < len(row) else ""
        href = row[i_name][1] if i_name < len(row) else None
        if not raw_name or MONEY.search(raw_name):
            continue
        name, num, variant = clean_name(raw_name)
        if not name:
            continue
        if not num:
            num = re.sub(r"[^A-Za-z0-9]", "", cell("num"))[:8]
        v9, v10 = money(cell("v9")), money(cell("v10"))
        if v9 is None and v10 is None:
            continue
        out.append({"name": name, "num": num, "variant": variant or "Holo",
                    "v9": v9, "v10": v10, "href": href})
    return out, roles


POP_NEAR = re.compile(r"PSA\s*(9|10)\b[^0-9$]{0,60}?([\d,]{1,7})", re.I)


def parse_card_pop(html):
    """Best effort PSA 9 / PSA 10 population off a card page."""
    p9 = p10 = None
    # 1: a table that labels a population column
    for tbl in tables_of(html):
        if len(tbl) < 2:
            continue
        roles = header_map(tbl[0])
        if "pop9" in roles or "pop10" in roles:
            for row in tbl[1:]:
                if "pop9" in roles and roles["pop9"] < len(row):
                    p9 = p9 if p9 is not None else count(row[roles["pop9"]][0])
                if "pop10" in roles and roles["pop10"] < len(row):
                    p10 = p10 if p10 is not None else count(row[roles["pop10"]][0])
        # 2: a two-column label/value population block
        flat = " ".join(c[0] for row in tbl for c in row)
        if "population" in flat.lower() or "pop report" in flat.lower():
            for grade, num in POP_NEAR.findall(flat):
                val = count(num) if COUNT.match(num) else None
                if val is None:
                    continue
                if grade == "9" and p9 is None:
                    p9 = val
                elif grade == "10" and p10 is None:
                    p10 = val
    # 3: last resort, scan the stripped page text
    if p9 is None and p10 is None:
        text = re.sub(r"<[^>]+>", " ", html)
        text = re.sub(r"\s+", " ", text)
        window = ""
        low = text.lower()
        for marker in ("population", "pop report", "psa pop"):
            k = low.find(marker)
            if k >= 0:
                window = text[k:k + 1200]
                break
        for grade, num in POP_NEAR.findall(window or ""):
            val = count(num)
            if val is None:
                continue
            if grade == "9" and p9 is None:
                p9 = val
            elif grade == "10" and p10 is None:
                p10 = val
    return p9, p10


# ---------------------------------------------------------------- output

def write_output(cards, outdir, generated):
    payload = {"generated": generated, "source": "pricecharting.com", "cards": cards}
    js_path = os.path.join(outdir, "holo-data.js")
    with open(js_path, "w", encoding="utf-8") as fh:
        fh.write("window.HOLO_DATA = ")
        json.dump(payload, fh, indent=1, ensure_ascii=False)
        fh.write(";\n")
    with open(os.path.join(outdir, "holo-data.json"), "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=1, ensure_ascii=False)
    return js_path


def merge_existing(outdir, cards):
    """Keep numbers from an earlier run that this run did not refresh."""
    path = os.path.join(outdir, "holo-data.json")
    if not os.path.exists(path):
        return cards
    try:
        with open(path, encoding="utf-8") as fh:
            old = json.load(fh).get("cards", [])
    except Exception:                                  # noqa: BLE001
        return cards
    index = {(c.get("set"), c.get("num"), c.get("name")): c for c in cards}
    for c in old:
        k = (c.get("set"), c.get("num"), c.get("name"))
        if k in index:
            cur = index[k]
            for f in ("v9", "v10", "p9", "p10"):
                if cur.get(f) is None and c.get(f) is not None:
                    cur[f] = c[f]
        else:
            cards.append(c)
    return cards


# ---------------------------------------------------------------- main

def run():
    ap = argparse.ArgumentParser(description="Refresh PSA 9/10 values and pop for the holo dashboard.")
    ap.add_argument("--all", action="store_true", help="every set in the list")
    ap.add_argument("--sets", help="comma separated set names")
    ap.add_argument("--pop", action="store_true", help="also fetch each card page for population")
    ap.add_argument("--pop-limit", type=int, default=40, help="max card pages per set (default 40)")
    ap.add_argument("--file", help="parse a saved HTML page instead of fetching")
    ap.add_argument("--set", help="set name that --file belongs to")
    ap.add_argument("--inspect", action="store_true", help="print the parser's view of the page")
    ap.add_argument("--fresh", action="store_true", help="ignore the on-disk cache")
    ap.add_argument("--delay", type=float, default=2.0, help="seconds between requests (default 2)")
    ap.add_argument("--out", default=".", help="where to write holo-data.js (default here)")
    args = ap.parse_args()

    jobs = []
    if args.file:
        if not args.set:
            ap.error("--file needs --set \"Set Name\"")
        jobs = [(args.set, None)]
    elif args.all:
        jobs = [(n, s) for n, s in SETS]
    elif args.sets:
        for name in [x.strip() for x in args.sets.split(",") if x.strip()]:
            match = next((n for n, _ in SETS if n.lower() == name.lower()), None)
            if not match:
                print("unknown set: %s" % name, file=sys.stderr)
                continue
            jobs.append((match, SLUG[match]))
    if not jobs:
        ap.error("pick --all, --sets \"A,B\" or --file page.html --set \"A\"")

    cards, generated = [], time.strftime("%Y-%m-%d %H:%M")
    for name, slug in jobs:
        print("%s" % name)
        if args.file:
            with open(os.path.expanduser(args.file), encoding="utf-8", errors="replace") as fh:
                html = fh.read()
        else:
            url = "%s/console/%s?sort=model-number&view=table" % (BASE, slug)
            html = fetch(url, args.delay, not args.fresh)
        if not html:
            continue

        if args.inspect:
            for t, tbl in enumerate(tables_of(html)[:6]):
                print("  table %d: %d rows" % (t, len(tbl)))
                for row in tbl[:3]:
                    print("    " + " | ".join(c[0][:28] for c in row[:9]))
            continue

        rows, roles = parse_set_page(html)
        print("  columns: %s" % (roles or "none found"))
        print("  %d priced rows" % len(rows))
        if not rows:
            print("  nothing parsed. Run again with --inspect and send me the output.")
        for r in rows:
            cards.append({"set": name, "num": r["num"], "name": r["name"],
                          "variant": r["variant"], "v9": r["v9"], "v10": r["v10"],
                          "p9": None, "p10": None})

        if args.pop and not args.file:
            todo = [r for r in rows if r.get("href")][:args.pop_limit]
            print("  population: %d card pages" % len(todo))
            got = 0
            for i, r in enumerate(todo, 1):
                href = r["href"]
                url = href if href.startswith("http") else BASE + href
                page = fetch(url, args.delay, not args.fresh)
                if not page:
                    continue
                p9, p10 = parse_card_pop(page)
                if p9 is not None or p10 is not None:
                    got += 1
                for c in cards:
                    if c["set"] == name and c["name"] == r["name"] and c["num"] == r["num"]:
                        c["p9"], c["p10"] = p9, p10
                if i % 10 == 0:
                    print("    %d/%d" % (i, len(todo)))
            print("  population found on %d of %d" % (got, len(todo)))

    if args.inspect:
        return

    outdir = os.path.expanduser(args.out)
    cards = merge_existing(outdir, cards)
    path = write_output(cards, outdir, generated)
    with_v = sum(1 for c in cards if c.get("v9") or c.get("v10"))
    with_p = sum(1 for c in cards if c.get("p9") or c.get("p10"))
    print("\nwrote %s" % path)
    print("%d cards, %d with values, %d with population" % (len(cards), with_v, with_p))
    print("Reload the dashboard to pick it up.")


if __name__ == "__main__":
    run()
